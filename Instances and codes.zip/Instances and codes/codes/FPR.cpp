#include <stdlib.h>
#include <stdio.h>
#include <algorithm>
#include <utility>
#include <iostream>
#include <fstream>
#include <sstream>
#include <time.h>
#include <math.h>
#include <string.h>
using namespace std;
#define MAXN 1004
#define MAXM 5004
#define MAXL 104
#define MAX 10000000
ifstream FI,FI2;
ofstream FO,FO2;
string Input_File_Name, Output_File_Name;
string Input2_File_Name, Output2_File_Name;
unsigned rand_seed;
double  Max_caltime; 
int v_amount, e_amount, l_amount;
int lv_amount[MAXL], e_matrix[MAXN][MAXN];
int ve_matrix[MAXN][MAXN], ve_left_matrix[MAXN][MAXN];
int edge_crossing[MAXN][MAXN];
int max_crossing_edge[MAXN][2];
int vv_crossing[MAXN][MAXN];
int evaluate_vv_crossing[MAXN][MAXN];
int best_i, best_j;
int Per_n;
//unsigned short int  maxpc[MAXN][MAXN][MAXN];
 clock_t start , finish;
 int perturb_min, perturb_max;
 int ls_perturb_iter ;
 int rl_perturb_iter ;
 int total_perturb_number = 0;
 int total_iter_number = 0;
void Set_parameter(){

	//Input_File_Name  =  "C:\\Users\\pengbo\\Desktop\\Files\\pengbo\\min_max_arc_crossing\\MinMaxGDPlib\\Rome\\rome.30.40.59.txt";
	Input_File_Name  =  "C:\\Users\\pengbo\\Desktop\\Files\\pengbo\\min_max_arc_crossing\\MinMaxGDPlib\\connected\\c1000_3000_25_8_1.txt"; 
	//Input_File_Name  =  "C:\\Users\\pengbo\\Desktop\\Files\\pengbo\\min_max_arc_crossing\\MinMaxGDPlib\\uniform\\noug8-rnd-010.txt";
	//Input_File_Name  =  "C:\\Users\\pengbo\\Desktop\\Files\\pengbo\\min_max_arc_crossing\\MinMaxGDPlib\\North\\north.40.131.15.txt";
	Output_File_Name =  "C:\\Users\\pengbo\\Desktop\\Files\\pengbo\\min_max_arc_crossing\\output\\output1.txt";
	rand_seed = (unsigned)time(NULL) ;
	ls_perturb_iter  =40;
    rl_perturb_iter = 20;
	Max_caltime = 60;
	srand(rand_seed);
	perturb_min = 2;
}
inline int Random(int i){
	int random_number=(int)(( rand()/(double) RAND_MAX) *i+1);//����� 1----loop
		random_number=((random_number>i)?i:random_number);
		return random_number;
}
void Input(){
	
	FI.open(Input_File_Name);
	FO.open(Output_File_Name);
	if( FI.fail() ){

		cout << "## Error open, Input_File_Name " << Input_File_Name << endl;
		getchar();
		exit(0);
	}
	if( FO.fail() ){

		cout << "## Error open, Output_File_Name " << Output_File_Name << endl;
		getchar();
		exit(0);
	}

	string temp_str, str_density, str_edge;
 

	FI>>v_amount>>e_amount>>l_amount;
	//FO<<v_amount<<e_amount<<l_amount;
	for(int loop = 1; loop <= l_amount; loop++)
		FI>>lv_amount[loop];

	//memset(e_matrix ,0, (v_amount +2)* sizeof(e_matrix[0]));
	for(int loop1 = 0; loop1 <= v_amount; loop1++)
		for(int loop2 = 0; loop2 <= v_amount; loop2++)
			ve_matrix[loop1][loop2] = e_matrix[loop1][loop2]  = 0;
	//memset(v_degree ,0, (v_amount +2)* sizeof(v_degree[0]));

	int v_number1, v_number2;
	for(int loop = 1; loop <= e_amount; loop++)
	{
		FI>>v_number1>>v_number2;
		e_matrix[v_number1][v_number2] = e_matrix[v_number2][v_number1] = 1;
		//e_situation[loop][1] = v_number1, e_situation[loop][2] = v_number2;
		//FO<<v_number1<<" "<<v_number2;
		//v_degree[v_number1] ++;
		ve_matrix[v_number1][0]++;
		ve_left_matrix[v_number2][0]++;
		ve_matrix[v_number1][ ve_matrix[v_number1][0] ] = v_number2;
		ve_left_matrix[v_number2][ ve_left_matrix[v_number2][0] ] = v_number1;
	}
	
	perturb_max =   l_amount*3;
	cout<<perturb_max<<endl;
}
void Time(){

	double second;
	finish=clock();
	second=(double)(finish-start)/CLOCKS_PER_SEC;
    //cout<<"Running time: "<<second<<"  Seconds."<<endl;
	FO<<"Running time: "<<second<<"  Seconds.";
}
struct Genetype{

	int gene[MAXL][MAXN];
	int max_crossing_value;
	int max_crossing_number;
	int max_crossing_edge[MAXM][2] ;
	int vertex_position[MAXN][2];


	Genetype(){
			
			for(int i = 1; i <= l_amount; i++)
				for(int j = 1; j <= lv_amount[i]; j ++)
					gene[i][j] = 0;
			max_crossing_value = max_crossing_number = -1;
	}

	Genetype(const Genetype &b){

		max_crossing_value = b.max_crossing_value;
		max_crossing_number = b.max_crossing_number;
		for(int i = 0; i <= l_amount; i++)
				for(int j = 0; j <= lv_amount[i]; j ++)
					gene[i][j] = b.gene[i][j];
		for(int i = 1; i <= max_crossing_number; i++)
			max_crossing_edge[i][0] = b.max_crossing_edge[i][0], max_crossing_edge[i][1] = b.max_crossing_edge[i][1];

		for(int i = 1; i <= v_amount; i++){
			vertex_position[ i][ 0 ] = b.vertex_position[ i][ 0 ], vertex_position[ i][ 1 ] = b.vertex_position[ i][ 1 ]; 
		}
	}

	void operator =(const Genetype &b){

		max_crossing_value = b.max_crossing_value;
		max_crossing_number = b.max_crossing_number;
		for(int i = 0; i <= l_amount; i++)
				for(int j = 0; j <= lv_amount[i]; j ++)
					gene[i][j] = b.gene[i][j];
		for(int i = 1; i <= max_crossing_number; i++)
			max_crossing_edge[i][0] = b.max_crossing_edge[i][0], max_crossing_edge[i][1] = b.max_crossing_edge[i][1];
		for(int i = 1; i <= v_amount; i++){
			vertex_position[ i][ 0 ] = b.vertex_position[ i][ 0 ], vertex_position[ i][ 1 ] = b.vertex_position[ i ][ 1 ]; 
		}
	}

	bool operator <(const Genetype &b){

		if(max_crossing_value< b.max_crossing_value )
			return true;
		else if(max_crossing_value== b.max_crossing_value && max_crossing_number < b.max_crossing_number )
			return true;
		else
			return false;

	}

	bool operator >(const Genetype &b){

		if(max_crossing_value >  b.max_crossing_value )
			return true;
		else if(max_crossing_value== b.max_crossing_value && max_crossing_number > b.max_crossing_number )
			return true;
		else
			return false;
	}

	bool operator == (const Genetype &b){

		if(max_crossing_value == b.max_crossing_value &&  max_crossing_number == b.max_crossing_number)
			return true;
		else
			return false;
	}
	

}S0, global_best;

 bool  granular_local_search(Genetype &solution);
int Check( Genetype &solution){
	int check_number = 0;
	int temp_vertex[MAXN];
	memset(temp_vertex ,0, (v_amount +2)* sizeof(temp_vertex[0]));
	//gene
	for(int i = 1; i <= l_amount; i++){
		for(int j = 1; j <= lv_amount[i]; j++){

			int temp = solution.gene[i][j];
			temp_vertex[ temp ] = 1;
		}
	}
	for(int i = 1; i <= v_amount; i++){
		if(temp_vertex[i] != 1){
			check_number = 1;
			cout<<"1��gene error"<<endl;
			return check_number;
		}
	}
	//vertex position
	for(int i = 1; i <= l_amount; i++){
		for(int j = 1; j <= lv_amount[i]; j++){
			int temp = solution.gene[i][j];
			if(i == solution.vertex_position[temp][0] && j == solution.vertex_position[temp][1])
				;
			else{
				check_number = 2;
				cout<<"2: vertex_position error"<<endl;
				return check_number;
			}
		}
	}
	//vv_position
	int max_crossing_value = -1;
	int max_crossing_number = -1;
	int v1, v2, v3, v4;
	for(int l_loop = 1; l_loop <  l_amount; l_loop++){

		for(int v_loop1 = 1; v_loop1 <= lv_amount[l_loop]; v_loop1++){
			v1 = solution.gene[l_loop][v_loop1];

			for(int v_loop2 = 1; v_loop2 <= ve_matrix[v1][0]; v_loop2++){
				v2 = ve_matrix[v1][v_loop2];
				int v2_position = solution.vertex_position[v2][1];
				int sum_crossing = 0;

				for(int v_loop3 = 1; v_loop3 <= lv_amount[l_loop]; v_loop3++){
					if(v_loop1 == v_loop3)
						continue;
					v3 = solution.gene[l_loop][v_loop3];

					for(int v_loop4 = 1; v_loop4 <= ve_matrix[v3][0]; v_loop4++){
						v4 = ve_matrix[v3][v_loop4];
						int v4_position = solution.vertex_position[v4][1];
						if(v4_position == v2_position)
							continue;

						if((v_loop1 - v_loop3) * (v2_position - v4_position) < 0)// has a crossing
							sum_crossing ++;

					}
				}
				vv_crossing[ v1 ][ v2 ] = vv_crossing[v2][v1] = sum_crossing;
				if(sum_crossing > max_crossing_value){
					max_crossing_value = sum_crossing;
					max_crossing_number = 1;
					max_crossing_edge[ max_crossing_number  ][ 0 ] = v1;
					max_crossing_edge[ max_crossing_number  ][ 1 ] = v2;

				}
				else if(sum_crossing == max_crossing_value){

					max_crossing_number++;
					max_crossing_edge[ max_crossing_number  ][ 0 ] = v1;
					max_crossing_edge[ max_crossing_number  ][ 1 ] = v2;
				}
			}
		}
	}
	
	if(	solution.max_crossing_value  != max_crossing_value){
			check_number = 3;
			cout<<"3:  max_crossing_value errors:   "<<solution.max_crossing_value<<"_____"<<max_crossing_value<<endl;
			return check_number;
	}

	if(	solution.max_crossing_number  != max_crossing_number){
			check_number = 4;
			cout<<"4:  max_crossing_number errors"<<endl;
			return check_number;
	}
	
	for(int loop = 1 ; loop <= max_crossing_number ; loop++){
		if(	solution.max_crossing_edge[loop][0]  != max_crossing_edge[loop][0] || solution.max_crossing_edge[loop][1] != max_crossing_edge[loop][1]){
			check_number = 5;
			cout<<"5:  max_crossing_edge  errors"<<endl;
		}
		return check_number;
	}
	//cout<<"feasible solution"<<endl;
	return check_number;
}
//Genetype best_solution;

int Evaluate_Insert(Genetype &solution, int i){
	int max_crossing_value = solution.max_crossing_value;
	int current_vertex = i ;
	int current_position = solution.vertex_position[i][1];
	int current_layer = solution.vertex_position[i][0];
	int best_delta_value = MAX;
	//upwards insertion
	///Check(solution);
	int delta_value = 0;
	for(int j = current_position - 1; j >0; j--){ // i-> k; j->m
		int j_vertex = solution.gene[ current_layer ][  j ];
		//right evaluation
		for(int k = 1; k <= ve_matrix[ current_vertex ][0];  k++){
			int k_vertex = ve_matrix[ current_vertex ][k];
			int k_position = solution.vertex_position[k_vertex][1];
			if(j == current_position - 1)
				evaluate_vv_crossing[current_vertex][k_vertex]  =  evaluate_vv_crossing[k_vertex][current_vertex] = vv_crossing[current_vertex][k_vertex] ;//init i����k

			int temp_crossing = 0;
			int temp_noncrossing = 0;
			for(int m = 1; m <= ve_matrix[ j_vertex ][ 0 ]; m ++){
				int m_vertex = ve_matrix[  j_vertex ][ m ];
				int m_position = solution.vertex_position[m_vertex][1];
				//vv_crossing[ current_vertex ][ k ];
				if(k == 1)
					evaluate_vv_crossing[j_vertex][m_vertex] = evaluate_vv_crossing[j_vertex][m_vertex]  =  vv_crossing[j_vertex][m_vertex] ;//init j����m

				if((j - current_position ) * (m_position -  k_position) < 0 ){ // crossing
					temp_crossing ++;
					evaluate_vv_crossing[j_vertex][m_vertex] --;
					evaluate_vv_crossing[m_vertex][j_vertex]  = evaluate_vv_crossing[j_vertex][m_vertex] ;
				}
				else if((j - current_position ) * (m_position -  k_position) > 0 ){
					temp_noncrossing ++;
					evaluate_vv_crossing[j_vertex][m_vertex] ++;
					evaluate_vv_crossing[m_vertex][j_vertex]  = evaluate_vv_crossing[j_vertex][m_vertex] ;
				}

			}

			int previous_crossing_value = evaluate_vv_crossing[current_vertex][k_vertex] ;
			int current_crossing_value = previous_crossing_value + temp_noncrossing - temp_crossing;

			if(previous_crossing_value == max_crossing_value && current_crossing_value < max_crossing_value ){ 

				delta_value --;
			}
			else if(previous_crossing_value < max_crossing_value && current_crossing_value == max_crossing_value ){
				delta_value ++;
			}
			else if( current_crossing_value > max_crossing_value ){
				delta_value +=  v_amount*(current_crossing_value - max_crossing_value) + 1;
			}
			
			evaluate_vv_crossing[current_vertex][k_vertex]  = evaluate_vv_crossing[k_vertex][current_vertex] =  current_crossing_value;
		}//k
		// check the j_vertex 
		for(int m = 1; m <= ve_matrix[ j_vertex ][ 0 ]; m ++){
				int m_vertex = ve_matrix[  j_vertex ][ m ];
				int m_position = solution.vertex_position[m_vertex][1];
				int j_previous_crossing_value = vv_crossing[j_vertex][m_vertex] ;
				int j_current_crossing_value = evaluate_vv_crossing[j_vertex][m_vertex] ;

			if(j_previous_crossing_value == max_crossing_value && j_current_crossing_value < max_crossing_value ){ 

				delta_value --;
			}
			else if(j_previous_crossing_value < max_crossing_value && j_current_crossing_value == max_crossing_value ){
				delta_value ++;
			}
			else if( j_current_crossing_value > max_crossing_value ){
				delta_value +=  v_amount*(j_current_crossing_value - max_crossing_value) + 1;
			}
		}
			

		//left evaluation
		for(int k = 1; k <= ve_left_matrix[ current_vertex ][0];  k++){
			int k_vertex = ve_left_matrix[ current_vertex ][k];
			int k_position = solution.vertex_position[k_vertex][1];
			if(j == current_position - 1)
				evaluate_vv_crossing[current_vertex][k_vertex]  =  evaluate_vv_crossing[k_vertex][current_vertex] = vv_crossing[current_vertex][k_vertex] ;//init i����k

			int temp_crossing = 0;
			int temp_noncrossing = 0;
			for(int m = 1; m <= ve_left_matrix[ j_vertex ][ 0 ]; m ++){
				int m_vertex = ve_left_matrix[  j_vertex ][ m ];
				int m_position = solution.vertex_position[m_vertex][1];
				if(k == 1)
					evaluate_vv_crossing[j_vertex][m_vertex] = evaluate_vv_crossing[j_vertex][m_vertex]  =  vv_crossing[j_vertex][m_vertex] ;//init j����m
				//vv_crossing[ current_vertex ][ k ];
				
				if((j - current_position ) * (m_position -  k_position) < 0 ) {// crossing
					temp_crossing ++;
					evaluate_vv_crossing[j_vertex][m_vertex] --;
					evaluate_vv_crossing[m_vertex][j_vertex]  = evaluate_vv_crossing[j_vertex][m_vertex] ;
				}
				else if((j - current_position ) * (m_position -  k_position) > 0 ){
					temp_noncrossing ++;
					evaluate_vv_crossing[j_vertex][m_vertex] ++;
					evaluate_vv_crossing[m_vertex][j_vertex]  = evaluate_vv_crossing[j_vertex][m_vertex] ;
				}

				//evaluate_vv_crossing[j_vertex][m_vertex]  = vv_crossing[j_vertex][m_vertex] + temp_noncrossing - temp_crossing;
			}

			int previous_crossing_value = evaluate_vv_crossing[current_vertex][k_vertex] ;
			int current_crossing_value = previous_crossing_value + temp_noncrossing - temp_crossing;

			if(previous_crossing_value == max_crossing_value && current_crossing_value < max_crossing_value ){ 

				delta_value --;
			}
			else if(previous_crossing_value < max_crossing_value && current_crossing_value == max_crossing_value ){
				delta_value ++;
			}
			else if( current_crossing_value > max_crossing_value ){
				delta_value +=  v_amount*(current_crossing_value - max_crossing_value) + 1;
			}
			
			evaluate_vv_crossing[current_vertex][k_vertex]  = evaluate_vv_crossing[k_vertex][current_vertex]  = current_crossing_value;
	 }//k

		// check the j_vertex 
		for(int m = 1; m <= ve_left_matrix[ j_vertex ][ 0 ]; m ++){
				int m_vertex = ve_left_matrix[  j_vertex ][ m ];
				int m_position = solution.vertex_position[m_vertex][1];
				int j_previous_crossing_value = vv_crossing[j_vertex][m_vertex] ;
				int j_current_crossing_value = evaluate_vv_crossing[j_vertex][m_vertex] ;

			if(j_previous_crossing_value == max_crossing_value && j_current_crossing_value < max_crossing_value ){ 

				delta_value --;
			}
			else if(j_previous_crossing_value < max_crossing_value && j_current_crossing_value == max_crossing_value ){
				delta_value ++;
			}
			else if( j_current_crossing_value > max_crossing_value ){
				delta_value +=  v_amount*(j_current_crossing_value - max_crossing_value) + 1;
			}
		}

		if(delta_value < best_delta_value){

			best_delta_value = delta_value;
			best_i = current_vertex;
			best_j = j_vertex;
			//if(best_delta_value < 0)
				//return best_delta_value;
		}
	}//j
	/*************downwards insertion*******/
	delta_value = 0;
	for(int j = current_position + 1; j  <= lv_amount[current_layer]; j++){ // i-> k; j->m
		int j_vertex = solution.gene[ current_layer ][  j ];
		//right evaluation
		for(int k = 1; k <= ve_matrix[ current_vertex ][0];  k++){
			int k_vertex = ve_matrix[ current_vertex ][k];
			int k_position = solution.vertex_position[k_vertex][1];
			if(j == current_position + 1)
				evaluate_vv_crossing[current_vertex][k_vertex]  =  evaluate_vv_crossing[k_vertex][current_vertex] = vv_crossing[current_vertex][k_vertex] ;//init i����k

			int temp_crossing = 0;
			int temp_noncrossing = 0;
			for(int m = 1; m <= ve_matrix[ j_vertex ][ 0 ]; m ++){
				int m_vertex = ve_matrix[  j_vertex ][ m ];
				int m_position = solution.vertex_position[m_vertex][1];
				if(k == 1)
					evaluate_vv_crossing[j_vertex][m_vertex] = evaluate_vv_crossing[j_vertex][m_vertex]  =  vv_crossing[j_vertex][m_vertex] ;//init j����m
				
				if((j - current_position ) * (m_position -  k_position) < 0 ){ // crossing
					temp_crossing ++;
					evaluate_vv_crossing[j_vertex][m_vertex] --;
					evaluate_vv_crossing[m_vertex][j_vertex]  = evaluate_vv_crossing[j_vertex][m_vertex] ;
				}
				else if((j - current_position ) * (m_position -  k_position) > 0 ){
					temp_noncrossing ++;
					evaluate_vv_crossing[j_vertex][m_vertex] ++;
					evaluate_vv_crossing[m_vertex][j_vertex]  = evaluate_vv_crossing[j_vertex][m_vertex] ;
				}

			}

			int previous_crossing_value = evaluate_vv_crossing[current_vertex][k_vertex] ;
			int current_crossing_value = previous_crossing_value + temp_noncrossing - temp_crossing;

			if(previous_crossing_value == max_crossing_value && current_crossing_value < max_crossing_value ){ 

				delta_value --;
			}
			else if(previous_crossing_value < max_crossing_value && current_crossing_value == max_crossing_value ){
				delta_value ++;
			}
			else if( current_crossing_value > max_crossing_value ){
				delta_value +=  v_amount*(current_crossing_value - max_crossing_value) + 1;
			}
			
			evaluate_vv_crossing[current_vertex][k_vertex]  = evaluate_vv_crossing[k_vertex][current_vertex]  = current_crossing_value;
		}//k
		// check the j_vertex 
		for(int m = 1; m <= ve_matrix[ j_vertex ][ 0 ]; m ++){
				int m_vertex = ve_matrix[  j_vertex ][ m ];
				int m_position = solution.vertex_position[m_vertex][1];
				int j_previous_crossing_value = vv_crossing[j_vertex][m_vertex] ;
				int j_current_crossing_value = evaluate_vv_crossing[j_vertex][m_vertex] ;

			if(j_previous_crossing_value == max_crossing_value && j_current_crossing_value < max_crossing_value ){ 

				delta_value --;
			}
			else if(j_previous_crossing_value < max_crossing_value && j_current_crossing_value == max_crossing_value ){
				delta_value ++;
			}
			else if( j_current_crossing_value > max_crossing_value ){
				delta_value +=  v_amount*(j_current_crossing_value - max_crossing_value) + 1;
			}
		}
			

		//left evaluation
		for(int k = 1; k <= ve_left_matrix[ current_vertex ][0];  k++){
			int k_vertex = ve_left_matrix[ current_vertex ][k];
			int k_position = solution.vertex_position[k_vertex][1];
			if(j == current_position + 1)
				evaluate_vv_crossing[current_vertex][k_vertex]  =  evaluate_vv_crossing[k_vertex][current_vertex] = vv_crossing[current_vertex][k_vertex] ;//init i����k
			int temp_crossing = 0;
			int temp_noncrossing = 0;
			for(int m = 1; m <= ve_left_matrix[ j_vertex ][ 0 ]; m ++){
				int m_vertex = ve_left_matrix[  j_vertex ][ m ];
				int m_position = solution.vertex_position[m_vertex][1];
				if(k == 1)
					evaluate_vv_crossing[j_vertex][m_vertex] = evaluate_vv_crossing[j_vertex][m_vertex]  =  vv_crossing[j_vertex][m_vertex] ;//init j����m

				if((j - current_position ) * (m_position -  k_position) < 0 ) {// crossing
					temp_crossing ++;
					evaluate_vv_crossing[j_vertex][m_vertex] --;
					evaluate_vv_crossing[m_vertex][j_vertex]  = evaluate_vv_crossing[j_vertex][m_vertex] ;
				}
				else if((j - current_position ) * (m_position -  k_position) > 0 ){
					temp_noncrossing ++;
					evaluate_vv_crossing[j_vertex][m_vertex] ++;
					evaluate_vv_crossing[m_vertex][j_vertex]  = evaluate_vv_crossing[j_vertex][m_vertex] ;
				}

				//evaluate_vv_crossing[j_vertex][m_vertex]  = vv_crossing[j_vertex][m_vertex] + temp_noncrossing - temp_crossing;
			}

			int previous_crossing_value = evaluate_vv_crossing[current_vertex][k_vertex] ;
			int current_crossing_value = previous_crossing_value + temp_noncrossing - temp_crossing;

			if(previous_crossing_value == max_crossing_value && current_crossing_value < max_crossing_value ){ 

				delta_value --;
			}
			else if(previous_crossing_value < max_crossing_value && current_crossing_value == max_crossing_value ){
				delta_value ++;
			}
			else if( current_crossing_value > max_crossing_value ){
				delta_value +=  v_amount*(current_crossing_value - max_crossing_value) + 1;
			}
			
			evaluate_vv_crossing[current_vertex][k_vertex]  =  evaluate_vv_crossing[k_vertex][current_vertex]= current_crossing_value;
		}//k

		// check the j_vertex 
		for(int m = 1; m <= ve_left_matrix[ j_vertex ][ 0 ]; m ++){
				int m_vertex = ve_left_matrix[  j_vertex ][ m ];
				int m_position = solution.vertex_position[m_vertex][1];
				int j_previous_crossing_value = vv_crossing[j_vertex][m_vertex] ;
				int j_current_crossing_value = evaluate_vv_crossing[j_vertex][m_vertex] ;

			if(j_previous_crossing_value == max_crossing_value && j_current_crossing_value < max_crossing_value ){ 

				delta_value --;
			}
			else if(j_previous_crossing_value < max_crossing_value && j_current_crossing_value == max_crossing_value ){
				delta_value ++;
			}
			else if( j_current_crossing_value > max_crossing_value ){
				delta_value +=  v_amount*(j_current_crossing_value - max_crossing_value) + 1;
			}
		}

		if(delta_value < best_delta_value || (delta_value == best_delta_value && Random(2) == 1)){

			best_delta_value = delta_value;
			best_i = current_vertex;
			best_j = j_vertex;
			//if(best_delta_value < 0)
				//return best_delta_value;
		}
 
	}//j

	return best_delta_value;
}
void Insert_i_j(Genetype &solution, int  best_i , int best_j ){

	//int max_crossing_value = solution.max_crossing_value;
	int current_vertex = best_i ;
	int current_position = solution.vertex_position[best_i][1];
	int best_i_layer = solution.vertex_position[best_i][0];
	int best_i_position = solution.vertex_position[ best_i ][1];
	int best_j_position = solution.vertex_position[ best_j ][1];
	

		//**************vv_crossing***********//
		//upwards Insertion
	for(int j = best_i_position - 1; j >= best_j_position ; j--){ // i-> k; j->m
			int j_vertex = solution.gene[ best_i_layer ][  j ];
			//right evaluation
			for(int k = 1; k <= ve_matrix[ best_i ][0];  k++){
				int k_vertex = ve_matrix[ best_i ][k];
				int k_position = solution.vertex_position[k_vertex][1];
				//evaluate_vv_crossing[best_i][k_vertex]  =  vv_crossing[best_i][k_vertex] ;

				int temp_crossing = 0;
				int temp_noncrossing = 0;
				for(int m = 1; m <= ve_matrix[ j_vertex ][ 0 ]; m ++){
					int m_vertex = ve_matrix[  j_vertex ][ m ];
					int m_position = solution.vertex_position[m_vertex][1];
					//vv_crossing[ current_vertex ][ k ];
				
					if((j - best_i_position ) * (m_position -  k_position) < 0 ) {// crossing{
						temp_crossing ++;
						vv_crossing[m_vertex][j_vertex]  =  -- vv_crossing[j_vertex][m_vertex] ;
						vv_crossing[k_vertex][best_i]  =  -- vv_crossing[best_i][k_vertex] ;
					}
					else if((j - best_i_position ) * (m_position -  k_position) > 0 ){
						temp_noncrossing ++;
						vv_crossing[m_vertex][j_vertex]  =  ++ vv_crossing[j_vertex][m_vertex] ;
						vv_crossing[k_vertex][best_i]  =  ++ vv_crossing[best_i][k_vertex] ;
					}

				//	vv_crossing[m_vertex][j_vertex] = vv_crossing[j_vertex][m_vertex]  = vv_crossing[j_vertex][m_vertex] + temp_noncrossing - temp_crossing;
				}
			}//k

			//left evaluation 
			for(int k = 1; k <= ve_left_matrix[ best_i ][0];  k++){
				int k_vertex = ve_left_matrix[ best_i ][k];
				int k_position = solution.vertex_position[k_vertex][1];
				//evaluate_vv_crossing[best_i][k_vertex]  =  vv_crossing[best_i][k_vertex] ;

				int temp_crossing = 0;
				int temp_noncrossing = 0;
				for(int m = 1; m <= ve_left_matrix[ j_vertex ][ 0 ]; m ++){
					int m_vertex = ve_left_matrix[  j_vertex ][ m ];
					int m_position = solution.vertex_position[m_vertex][1];
					//vv_crossing[ current_vertex ][ k ];
					if((j - best_i_position ) * (m_position -  k_position) < 0 ) {// crossing{
						temp_crossing ++;
						vv_crossing[m_vertex][j_vertex]  =  -- vv_crossing[j_vertex][m_vertex] ;
						vv_crossing[k_vertex][best_i]  =  -- vv_crossing[best_i][k_vertex] ;
					}
					else if((j - best_i_position ) * (m_position -  k_position) > 0 ){
						temp_noncrossing ++;
						vv_crossing[m_vertex][j_vertex]  =  ++ vv_crossing[j_vertex][m_vertex] ;
						vv_crossing[k_vertex][best_i]  =  ++ vv_crossing[best_i][k_vertex] ;
					}
				//	vv_crossing[m_vertex][j_vertex] = vv_crossing[j_vertex][m_vertex]  = vv_crossing[j_vertex][m_vertex] + temp_noncrossing - temp_crossing;
				}
			}//k
	}
	//****downwards Insertion**************
	for(int j = current_position + 1; j  <= best_j_position; j++){  // i-> k; j->m   for(int j = current_position + 1; j  <= lv_amount[current_layer]; j++){ 
			int j_vertex = solution.gene[ best_i_layer ][  j ];
			//right evaluation
			for(int k = 1; k <= ve_matrix[ best_i ][0];  k++){
				int k_vertex = ve_matrix[ best_i ][k];
				int k_position = solution.vertex_position[k_vertex][1];
				//evaluate_vv_crossing[best_i][k_vertex]  =  vv_crossing[best_i][k_vertex] ;

				int temp_crossing = 0;
				int temp_noncrossing = 0;
				for(int m = 1; m <= ve_matrix[ j_vertex ][ 0 ]; m ++){
					int m_vertex = ve_matrix[  j_vertex ][ m ];
					int m_position = solution.vertex_position[m_vertex][1];
					//vv_crossing[ current_vertex ][ k ];
				
					if((j - best_i_position ) * (m_position -  k_position) < 0 ) {// crossing{
						temp_crossing ++;
						vv_crossing[m_vertex][j_vertex]  =  -- vv_crossing[j_vertex][m_vertex] ;
						vv_crossing[k_vertex][best_i]  =  -- vv_crossing[best_i][k_vertex] ;
					}
					else if((j - best_i_position ) * (m_position -  k_position) > 0 ){
						temp_noncrossing ++;
						vv_crossing[m_vertex][j_vertex]  =  ++ vv_crossing[j_vertex][m_vertex] ;
						vv_crossing[k_vertex][best_i]  =  ++ vv_crossing[best_i][k_vertex] ;
					}

				//	vv_crossing[m_vertex][j_vertex] = vv_crossing[j_vertex][m_vertex]  = vv_crossing[j_vertex][m_vertex] + temp_noncrossing - temp_crossing;
				}
			}//k

			//left evaluation 
			for(int k = 1; k <= ve_left_matrix[ best_i ][0];  k++){
				int k_vertex = ve_left_matrix[ best_i ][k];
				int k_position = solution.vertex_position[k_vertex][1];
				//evaluate_vv_crossing[best_i][k_vertex]  =  vv_crossing[best_i][k_vertex] ;

				int temp_crossing = 0;
				int temp_noncrossing = 0;
				for(int m = 1; m <= ve_left_matrix[ j_vertex ][ 0 ]; m ++){
					int m_vertex = ve_left_matrix[  j_vertex ][ m ];
					int m_position = solution.vertex_position[m_vertex][1];
					//vv_crossing[ current_vertex ][ k ];
				
					if((j - best_i_position ) * (m_position -  k_position) < 0 ) {// crossing{
						temp_crossing ++;
						vv_crossing[m_vertex][j_vertex]  =  -- vv_crossing[j_vertex][m_vertex] ;
						vv_crossing[k_vertex][best_i]  =  -- vv_crossing[best_i][k_vertex] ;
					}
					else if((j - best_i_position ) * (m_position -  k_position) > 0 ){
						temp_noncrossing ++;
						vv_crossing[m_vertex][j_vertex]  =  ++ vv_crossing[j_vertex][m_vertex] ;
						vv_crossing[k_vertex][best_i]  =  ++ vv_crossing[best_i][k_vertex] ;
					}

				//	vv_crossing[m_vertex][j_vertex] = vv_crossing[j_vertex][m_vertex]  = vv_crossing[j_vertex][m_vertex] + temp_noncrossing - temp_crossing;
				}
			}//k

	}

	/****************best neighborhood move*********************/
		//gene, vertex_position 
		if(best_j_position < best_i_position ){// upwards insertion

			for(int loop = best_i_position ; loop > best_j_position ; loop--){
				solution.gene[best_i_layer][loop] = solution.gene[best_i_layer][loop - 1];
				solution.vertex_position[ solution.gene[best_i_layer][loop] ][1] =  loop;
			}
			solution.gene[best_i_layer][best_j_position] = best_i;
			solution.vertex_position[ best_i ][1] = best_j_position;
		}

		else if(best_j_position > best_i_position ){// downwards insertion

			for(int loop = best_i_position; loop < best_j_position ; loop++){
				solution.gene[best_i_layer][loop] = solution.gene[best_i_layer][loop + 1];
				solution.vertex_position[ solution.gene[best_i_layer][loop] ][1] =  loop;
			}
			solution.gene[best_i_layer][best_j_position] = best_i;
			solution.vertex_position[ best_i ][1] = best_j_position;
		}

	
	//calculate the maximum crossing of edge, value, 
	int max_crossing_value = -1;
	int max_crossing_number = -1;
	int v1, v2;
	for(int l_loop = 1; l_loop <=  l_amount; l_loop++){

		for(int v_loop1 = 1; v_loop1 <= lv_amount[l_loop]; v_loop1++){
			v1 = solution.gene[l_loop][v_loop1];

			for(int v_loop2 = 1; v_loop2 <= ve_matrix[v1][0]; v_loop2++){
				v2 = ve_matrix[v1][v_loop2];
				int v2_position = solution.vertex_position[v2][1];
				int sum_crossing = 0;

				
				sum_crossing  = vv_crossing[ v1 ][ v2 ] ;
				if(sum_crossing > max_crossing_value){
					max_crossing_value = sum_crossing;
					max_crossing_number = 1;
					max_crossing_edge[ max_crossing_number  ][ 0 ] = v1;
					max_crossing_edge[ max_crossing_number  ][ 1 ] = v2;

				}
				else if(sum_crossing == max_crossing_value){

					max_crossing_number++;
					max_crossing_edge[ max_crossing_number  ][ 0 ] = v1;
					max_crossing_edge[ max_crossing_number  ][ 1 ] = v2;
				}
			}
		}
	}

	// max_crossing value , number and dege
	solution.max_crossing_number  = max_crossing_number  ;
	solution.max_crossing_value = max_crossing_value;
	for(int loop = 1 ; loop <= max_crossing_number ; loop++)
		solution.max_crossing_edge[loop][0] = max_crossing_edge[loop][0], solution.max_crossing_edge[loop][1] = max_crossing_edge[loop][1];

}

int temp_vertex[MAXN];
int critical_vertex[MAXN];
bool Local_Search(Genetype &solution){
	memset(temp_vertex ,0, (v_amount +2)* sizeof(temp_vertex[0]));
	//choose the critical vertices
	int max_crossing_number = solution.max_crossing_number;
	for(int i = 1; i<= max_crossing_number; i++){
		int p1_vertex = max_crossing_edge[i][0];
		int p1_position = solution.vertex_position[p1_vertex][1];
		int p2_vertex = max_crossing_edge[i][1];
		int p2_position = solution.vertex_position[p2_vertex][1];
		int p1_layer = solution.vertex_position[p1_vertex][0];
		int p2_layer = solution.vertex_position[p2_vertex][0];

		temp_vertex[p1_vertex] = temp_vertex[p2_vertex] = 1;
		for(int j = 1; j <= lv_amount[p1_layer]; j++){
			int p3_vertex = solution.gene[p1_layer][j];
			int p3_position = j;
			if(p3_vertex == p1_vertex)
				continue;

			for(int k = 1; k<= ve_matrix[p3_vertex][0]; k++){
				int p4_vertex = ve_matrix[p3_vertex][k];
				int p4_position = solution.vertex_position[p4_vertex][1];
				if(p4_vertex == p2_vertex)
					continue;
				if((p3_position - p1_position)*(p4_position - p2_position) < 0) // crossing
					temp_vertex[p3_vertex] = temp_vertex[p4_vertex] = 1;
			}
		}
	}
	
	int critical_number =0;
	for(int i = 1; i <= v_amount; i++){
		if(temp_vertex[i] == 1){
			critical_number ++;
			critical_vertex[ critical_number ] = i;
		}
	}
	for(int j = 1; j <= critical_number; j ++){
			int p1 =  Random(critical_number);
			int p2 =  Random(critical_number);
			if(p2 == p1)
				p2 = p1+1;
			if(p2 > critical_number)
				p2 = 1;
			swap(critical_vertex[p1], critical_vertex[p2]);
	}
	//Evaluate the critical vertex
	int insert_i, insert_j, evaluate_vertex, delta_value;
	int best_delta_value=MAX;
	for(int i = 1; i <= critical_number; i++){//critical_number
		evaluate_vertex = critical_vertex[i];
		delta_value = Evaluate_Insert(solution, evaluate_vertex);
		if(delta_value <best_delta_value){

			best_delta_value = delta_value;
			insert_i = best_i;
			insert_j = best_j;
		}
	   if(best_delta_value <0)
			break;
	}

	if(best_delta_value < 0){
			//Check(solution);
			Insert_i_j(solution, insert_i, insert_j);
			//Check(solution);
			return true;
	}
	else{
			return false;
	}

}
void Cal_Obj(Genetype &solution){

	int max_crossing_value = -1;
	int max_crossing_number = -1;
 
	//calculate the position of each vertex in the corresponding layer, vertex_position
	for(int i = 1; i <= l_amount; i++)
		for(int j = 1; j <= lv_amount[i]; j++){

			int temp_vertex = solution.gene[i][j];
			solution.vertex_position[ temp_vertex][ 0 ] = i, solution.vertex_position[ temp_vertex][ 1 ] = j; 
		}
	//calculate the maximum crossing of edge,  vv_crossing
	int v1, v2, v3, v4;
	for(int l_loop = 1; l_loop <  l_amount; l_loop++){

		for(int v_loop1 = 1; v_loop1 <= lv_amount[l_loop]; v_loop1++){
			v1 = solution.gene[l_loop][v_loop1];

			for(int v_loop2 = 1; v_loop2 <= ve_matrix[v1][0]; v_loop2++){
				v2 = ve_matrix[v1][v_loop2];
				int v2_position = solution.vertex_position[v2][1];
				int sum_crossing = 0;

				for(int v_loop3 = 1; v_loop3 <= lv_amount[l_loop]; v_loop3++){
					if(v_loop1 == v_loop3)
						continue;
					v3 = solution.gene[l_loop][v_loop3];

					for(int v_loop4 = 1; v_loop4 <= ve_matrix[v3][0]; v_loop4++){
						v4 = ve_matrix[v3][v_loop4];
						int v4_position = solution.vertex_position[v4][1];
						if(v4_position == v2_position)
							continue;

						if((v_loop1 - v_loop3) * (v2_position - v4_position) < 0)// has a crossing
							sum_crossing ++;

					}
				}
				vv_crossing[ v1 ][ v2 ] = vv_crossing[v2][v1] = sum_crossing;
				if(sum_crossing > max_crossing_value){
					max_crossing_value = sum_crossing;
					max_crossing_number = 1;
					max_crossing_edge[ max_crossing_number  ][ 0 ] = v1;
					max_crossing_edge[ max_crossing_number  ][ 1 ] = v2;

				}
				else if(sum_crossing == max_crossing_value){

					max_crossing_number++;
					max_crossing_edge[ max_crossing_number  ][ 0 ] = v1;
					max_crossing_edge[ max_crossing_number  ][ 1 ] = v2;
				}
			}
		}
	}

	// max_crossing value , number and dege
	solution.max_crossing_number  = max_crossing_number  ;
	solution.max_crossing_value = max_crossing_value;
	for(int loop = 1 ; loop <= max_crossing_number ; loop++)
		solution.max_crossing_edge[loop][0] = max_crossing_edge[loop][0], solution.max_crossing_edge[loop][1] = max_crossing_edge[loop][1];

 
}
Genetype solution;
Genetype Perturb(Genetype &global_best, int perturb_strength = v_amount/3){
	solution = global_best;
	//int perturbation_strength =  perturb_strength;//min(v_amount / Per_n, max(no_improve_iter, 2));//1 + Random(v_amount / Per_n);
	int temp_number = perturb_strength;
	while(temp_number--){

		//temp_vertex = Random(v_amount);
		int current_layer = Random(l_amount);
		int current_position = Random(lv_amount[current_layer]);
		int current_vertex = solution.gene[current_layer][current_position];
		int insert_position = Random(lv_amount[current_layer]);
		if(insert_position == current_position)
			insert_position = current_position + 1;
		if(insert_position > lv_amount[current_layer])
			insert_position = 1 ;
		//insert current_vertex into position iter_position.

		if(insert_position < current_position ){// upwards insertion

			for(int loop = current_position; loop > insert_position ; loop--){
				solution.gene[current_layer][loop] = solution.gene[current_layer][loop - 1];
				solution.vertex_position[ solution.gene[current_layer][loop] ][1] =  loop;
			}
			solution.gene[current_layer][insert_position] = current_vertex;
			solution.vertex_position[ current_vertex ][1] = insert_position;
		}

		else if(insert_position > current_position ){// downwards insertion

			for(int loop = current_position; loop < insert_position ; loop++){
				solution.gene[current_layer][loop] = solution.gene[current_layer][loop + 1];
				solution.vertex_position[ solution.gene[current_layer][loop] ][1] =  loop;
			}
			solution.gene[current_layer][insert_position] = current_vertex;
			solution.vertex_position[ current_vertex ][1] = insert_position;
		}
	}
	//Recalculate DS
	total_perturb_number++;
	Cal_Obj(solution);
	return solution;

}
void Graph(Genetype&solution){
	for(int i = 1; i <= l_amount; i++){
				for(int j = 1; j <= lv_amount[i]; j ++)
					FO<<solution.gene[i][j]<<" ";
				FO<<endl;
	}
	FI.close();                 // close and clear the index of the input and output files
	FI.clear();
	FO.close();
	FO.clear();
	fcloseall();
	char output_file[100];
	strcpy(output_file, Output_File_Name.c_str());
	system(output_file); 
}
void Init(){

	int temp_number = 0;
	//randomly generate the initial solution
	for(int i = 1; i <= l_amount; i++){
		for(int j = 1; j <= lv_amount[i]; j ++){
			temp_number  ++;
			S0.gene[i][j] = temp_number;
		}

		for(int j = 1; j <= lv_amount[i]; j ++){

			int p1 =  Random(lv_amount[i]);
			int p2 =  Random(lv_amount[i]);
			if(p1 != p2)
				swap(S0.gene[i][p1], S0.gene[i][p2]);
		}
	}
	Cal_Obj(S0);
	//Graph(S0);
	//LocalSearch();
}
int delta_value[MAXN], insert_i[MAXN], insert_j[MAXN], dp[MAXL], DP[MAXL];

bool granular_local_search(Genetype &solution){
	
	//total_iter_number ++;
	memset(temp_vertex ,0, (v_amount +2)* sizeof(temp_vertex[0]));
	//choose the critical vertices
	int max_crossing_number = solution.max_crossing_number;
	for(int i = 1; i<= max_crossing_number; i++){//����MCE��Ӧ�Ľڵ㣬p1��p2
		int p1_vertex = max_crossing_edge[i][0];
		int p1_position = solution.vertex_position[p1_vertex][1];
		int p2_vertex = max_crossing_edge[i][1];
		int p2_position = solution.vertex_position[p2_vertex][1];
		int p1_layer = solution.vertex_position[p1_vertex][0];
		int p2_layer = solution.vertex_position[p2_vertex][0];

		temp_vertex[p1_vertex] = temp_vertex[p2_vertex] = 1;
		for(int j = 1; j <= lv_amount[p1_layer]; j++){  //����p1ͬ���p3�Լ�p3������p4
			int p3_vertex = solution.gene[p1_layer][j];
			if(p3_vertex == p1_vertex)
				continue;
			int p3_position = j;
			for(int k = 1; k<= ve_matrix[p3_vertex][0]; k++){
				int p4_vertex = ve_matrix[p3_vertex][k];
				if(p4_vertex == p2_vertex)
					continue;
				int p4_position = solution.vertex_position[p4_vertex][1];
				if((p3_position - p1_position)*(p4_position - p2_position) < 0) // ����������˵����õ��ؼ��ڵ�����temp_vertex
					temp_vertex[p3_vertex] = temp_vertex[p4_vertex] = 1;
			}
		}
	}
	
	int critical_number =0;
	for(int i = 1; i <= v_amount; i++){
		if(temp_vertex[i] == 1){
			critical_number ++;
			critical_vertex[ critical_number ] = i;
		}
	}
	for(int j = 1; j <= critical_number; j ++){
			int p1 =  Random(critical_number);
			int p2 =  Random(critical_number);
			if(p2 == p1)
				p2 = p1+1;
			if(p2 > critical_number)
				p2 = 1;
			swap(critical_vertex[p1], critical_vertex[p2]);
	}
	//Evaluate the critical vertex
	int evaluate_vertex, temp_delta_value;
	memset(delta_value ,0, (l_amount +2)* sizeof(delta_value[0]));
	for(int i = 1; i <= critical_number; i++){//critical_number
		evaluate_vertex = critical_vertex[i];
		int temp_layer_number = solution.vertex_position[evaluate_vertex][0];
		if(delta_value[temp_layer_number] <0)
			continue;
		temp_delta_value = Evaluate_Insert(solution, evaluate_vertex);
		/*if(delta_value <best_delta_value){

			best_delta_value = delta_value;
			insert_i = best_i;
			insert_j = best_j;
		}*/
		//if(best_delta_value <0)
			//break;
		if(temp_delta_value < delta_value[temp_layer_number]){
			delta_value[temp_layer_number] = temp_delta_value;
			insert_i[temp_layer_number] = best_i;
			insert_j[temp_layer_number] = best_j;
		}

	}
	memset(dp ,0, (l_amount +2) * sizeof(dp[0]));
	memset(DP ,0, (l_amount +2) * sizeof(DP[0]));
	dp[0] = 0, DP[0] = 0;
	dp[1] = delta_value[1], DP[1] = -1;
	for(int i = 2; i <= l_amount; i++){
		if(dp[i-1]  < dp[i-2] + delta_value[i]){

			dp[i] = dp[i-1], DP[i] = i-1; 
		}
		else{

			dp[i] = dp[i-2] + delta_value[i],  DP[i] = i - 2;
		}
	}

	//int temp_sum = 0;
	if(dp[l_amount] < 0){
		/*int loop1 = l_amount;
		do{

			if(DP[loop1 ] != loop1 - 1 && delta_value[loop1] < 0 ){
				temp_sum ++;
			}
			loop1 =  DP[  loop1 ];
		}while(loop1 > 0);
		*/
	   int   loop = l_amount;
		//int temp_number21 = 0;
		do{

			if(DP[loop ] != loop - 1 && delta_value[loop] < 0 ){
				int temp_i = insert_i[loop];
				int temp_j = insert_j[loop];
				Insert_i_j(solution, temp_i, temp_j);
			}
			loop =  DP[  loop ];
		}while(loop > 0);
		//if(temp_number21 >=2)
		//	cout<<" DP  "<<temp_number21;
		 return true;
	}
	else{
			return false;
	}
}
void Output(){
	FO<<"�Ŷ�����Ϊ��"<<total_perturb_number<<endl;
	Cal_Obj(global_best);
	if(Check(global_best) != 0 )
		FO<<"Infeasible solution"<<endl;
	else{
		
		FO<<"Feasible solution : "<<global_best.max_crossing_value<<endl;
	}
	FO<<endl<<" Rand_seed : "<< rand_seed <<endl;
 
	FO<<"Value = "<<global_best.max_crossing_value<<endl<<" Number  =  "<<global_best.max_crossing_number<<endl;
	for(int i = 1; i <= l_amount; i++){
			for(int j = 1; j <= lv_amount[i]; j ++)
					FO<<global_best.gene[i][j]<<" ";
			FO<<endl;
	}
	
	Time();
	FI.close();                 // close and clear the index of the input and output files
	FI.clear();
	FO.close();
	FO.clear();
	fcloseall();
	char output_file[100];
	strcpy(output_file, Output_File_Name.c_str());
	system(output_file); 

}

Genetype Initial_Solution(){
	int temp_number = 0;
	//randomly generate the initial solution
	for(int i = 1; i <= l_amount; i++){
		for(int j = 1; j <= lv_amount[i]; j ++){
			temp_number  ++;
			S0.gene[i][j] = temp_number;
		}
		for(int j = 1; j <= lv_amount[i]; j ++){

			int p1 =  Random(lv_amount[i]);
			int p2 =  Random(lv_amount[i]);
			if(p1 != p2)
				swap(S0.gene[i][p1], S0.gene[i][p2]);
		}
	}
	Cal_Obj(S0);
	return S0;
}
Genetype  pre_solution, local_best;
Genetype DPLS (Genetype & solution, int max_perturb_iter = ls_perturb_iter ){
	double second;
	local_best = solution;
   int perturb_strength = perturb_min;
   int perturb_iter = 0;
   Cal_Obj(solution);
	do{
		pre_solution = solution;
		//Check(solution);
		while(granular_local_search(solution)){
			//Check(solution);
			finish=clock();
			second=(double)(finish-start)/CLOCKS_PER_SEC;//Check(solution);
			if(second > Max_caltime)
				break;
		}
		//Compare the local optima with the global optima
		//Check(solution);
		if(solution < local_best){
			local_best = solution;
			perturb_strength = perturb_min;
		} 
		
		if (solution < global_best){
			    perturb_iter = 0;
				global_best = solution;
				finish=clock();
				double second=(double)(finish-start)/CLOCKS_PER_SEC;
				cout<<"max_crossing_value :  "<<solution.max_crossing_value<<"  ( "<<solution.max_crossing_number<<" ) , Time :  "<<second<<endl;
		}

		if(solution < pre_solution)
			perturb_strength = max( perturb_strength /2, perturb_min);
		else  
			perturb_strength = min( perturb_strength *2, perturb_max);
		solution = Perturb(local_best, perturb_strength);
		perturb_iter ++;
		finish=clock();
		second=(double)(finish-start)/CLOCKS_PER_SEC;
	}while(perturb_iter < max_perturb_iter && second <= Max_caltime);
	return local_best;
}
Genetype re_S, best_re_S,re_S_ls;
int l_amount_rand[MAXL];
Genetype  Relinking(Genetype &  S1, Genetype & S2){
	re_S = S1;
	for(int i = 1; i <= l_amount; i++){
		l_amount_rand[i] = i;
	}
	for(int i = 1; i <= l_amount; i++){
		int p1 =  Random(l_amount);
		int p2 =  Random(l_amount);
		if(p1 != p2)
			swap(l_amount_rand[p1], l_amount_rand[p2]);
	}

	int temp_max_crossing_value = MAX;
	int temp_max_crossing_number = MAX;
	for (int k = 1; k<= l_amount; k++){
		int i = l_amount_rand[k];
		for(int j = 1; j <= lv_amount[i]; j ++){
			re_S.gene[i][j] = S2.gene[i][j];
		}
		//Cal_Obj(re_S);
		re_S_ls = DPLS(re_S, rl_perturb_iter);
		//Cal_Obj(re_S_ls);
		if(re_S_ls.max_crossing_value < temp_max_crossing_value ){
			temp_max_crossing_value = re_S_ls.max_crossing_value;
			temp_max_crossing_number =    re_S_ls.max_crossing_number;
			best_re_S = re_S_ls;
		}
		else if(re_S_ls.max_crossing_value == temp_max_crossing_value &&   re_S_ls.max_crossing_number < temp_max_crossing_number ){

			temp_max_crossing_value = re_S_ls.max_crossing_value;
			temp_max_crossing_number =    re_S_ls.max_crossing_number;
			best_re_S = re_S_ls;
		}
	}
	return best_re_S;
}
Genetype S1,S2,S1c,S2c; 
void FPR(){
	start =clock();
	double second;
     S1 = Initial_Solution();
	 S2 =  Initial_Solution();
	 if(S1 < S2)
		 global_best = S1;
	 else
		global_best = S2;
	 int cycle_number = 0;
	 do{
		 S1 = DPLS(S1);
		 S2 = DPLS(S2); 
		 int s1p = S1.max_crossing_value;
		 int s2p = S2.max_crossing_value;
	   	S1c = Relinking(S1, S2);
		S2c =  Relinking( S2, global_best);
		 cout<<"before:  "<<S1c.max_crossing_value<<"," <<S1c.max_crossing_number<<" ;";
		 cout<<S2c.max_crossing_value<<"," <<S2c.max_crossing_number<<endl;
		 S1 = DPLS(S1c);
		 S2 = DPLS(S2c);
		 cout<<"after:  "<<S1.max_crossing_value<<"," <<S1.max_crossing_number<<" ;";
		 cout<<S2.max_crossing_value<<"," <<S2.max_crossing_number<<endl;
		 if( (S1.max_crossing_value == s1p && S2.max_crossing_value == s2p) || (S2.max_crossing_value == s1p && S1.max_crossing_value == s2p)||  (S1.max_crossing_value == S2.max_crossing_value)){
			 S2 = Initial_Solution(); 
			S1= global_best;
			 cout<<"newly generated solution:  "<<S1.max_crossing_value<<"  "<<S2.max_crossing_value<<endl;
		 }
		 second=(double)(clock()-start)/CLOCKS_PER_SEC;
	  }while(second <= Max_caltime);
	 

}
int main()
{
	Set_parameter();
	Input();
	Init();
	FPR();
	Output();
	return 1;

}