The input format for example can be presented as follows:  (Knock CMD command to enter the dos system under Windows Environment)
C:\Users\pengbo\exe_for_FPR.exe C:\Users\pengbo\MinMaxGDPlib\uniform\noug3-rnd-001.txt C:\Users\pengbo\results.txt 546526093 60 40 20

The first three parameters denote the path of exe file, input file and the final result file, respectively.
The next parameter (546526093 ) denote the random seed.
The last three parameters denote the running time, the parameter values of li and si, respectively.





